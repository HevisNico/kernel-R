from pathlib import Path
import json,sys,numpy as np
sys.path.insert(0,'experiments/reciprocal')
from engine import Device,NOMINAL,simulate
schedules=json.loads(Path('audit_runs/pedagogy_development/grid.json').read_text())['schedules']
rows=[]
for f in [0,1]:
 for i in range(24):
  rng=np.random.default_rng(419000+1000*f+i);g=rng.uniform(.285,.315) if f==0 else rng.uniform(1.33,1.47)
  b=rng.uniform(.23,.27);pars=(NOMINAL*rng.uniform(.9,1.1,(3,5))).tolist()
  for name,times in schedules.items():
   d=Device(pars,.1,[.025]*3,np.log([.3,g,.3]).tolist(),b,[0]*3);r=simulate([[],times,[]],d,180.)
   d.initial_z=np.log(r['final_gain']).tolist();d.initial_b=r['final_b'];q=simulate([[],[k*8. for k in range(8)],[]],d,84,mode='fixed')
   lat=[t-k*8 for k in range(8) for t in q['outputs'] if k*8<=t<(k+1)*8]
   ok=len(lat)==8 and all(.22<=x<=.5 for x in lat)
   rows.append(dict(family=f,student=i,action=name,success=ok,latencies=lat))
Path('audit_runs/pedagogy_development/curricula.json').write_text(json.dumps(rows,indent=2))
for name in schedules:
 vals=[sum(r['success'] for r in rows if r['family']==f and r['action']==name) for f in [0,1]]
 print(name,vals,'total',sum(vals),flush=True)
