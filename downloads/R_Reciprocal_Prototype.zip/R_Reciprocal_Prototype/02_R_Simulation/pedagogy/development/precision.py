from pathlib import Path
import sys,numpy as np,json
sys.path.insert(0,str(Path('experiments/reciprocal').resolve()))
from engine import Device,NOMINAL,simulate
rows=[]
for family in [0,1]:
 for i in range(40):
  rng=np.random.default_rng(417000+1000*family+i)
  g=rng.uniform(.285,.315) if family==0 else rng.uniform(1.33,1.47)
  b=rng.uniform(.23,.27);pars=(NOMINAL*rng.uniform(.9,1.1,(3,5))).tolist()
  d=Device(pars,.1,[.025]*3,np.log([.3,g,.3]).tolist(),b,[0]*3)
  diagnostic=simulate([[0.],[0.],[]],d,30.,mode='fixed')
  for action,gap in enumerate([1.4,8.]):
   r=simulate([[],[k*gap for k in range(10)],[]],d,100.)
   p=Device(pars,.1,[.025]*3,np.log(r['final_gain']).tolist(),r['final_b'],[0]*3)
   q=simulate([[],[k*8. for k in range(8)],[]],p,84,mode='fixed')
   lats=[t-k*8 for k in range(8) for t in q['outputs'] if k*8<=t<(k+1)*8]
   ok=len(lats)==8 and all(.22<=x<=.5 for x in lats)
   rows.append(dict(family=family,id=i,action=action,gain=g,b=b,diagnostic=len(diagnostic['outputs']),success=ok,g=r['final_gain'][1],recovery=r['final_b'],latencies=lats))
Path('audit_runs/pedagogy_development/precision.json').write_text(json.dumps(rows,indent=2))
for f in [0,1]:
 for a in [0,1]:
  rr=[r for r in rows if r['family']==f and r['action']==a];print(f,a,sum(r['success'] for r in rr),'/',len(rr),'diagnostic',sorted(set(r['diagnostic'] for r in rr)),'g',[round(min(r['g'] for r in rr),3),round(max(r['g'] for r in rr),3)])
