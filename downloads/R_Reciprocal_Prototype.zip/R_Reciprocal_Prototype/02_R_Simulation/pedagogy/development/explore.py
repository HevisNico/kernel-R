from pathlib import Path
import sys,numpy as np,json,itertools
sys.path.insert(0,str(Path('experiments/reciprocal').resolve()))
from engine import Device,NOMINAL,simulate
schedules={f'gap_{x}':[float(k*x) for k in range(10)] for x in [1.4,1.6,2,3,4,6,8,12,16]}
schedules.update({
 'slow_fast':[0.,12.,24.,36.,38.,40.,42.,44.,46.,48.],
 'fast_slow':[0.,2.,4.,6.,8.,10.,22.,34.,46.,58.],
 'pairs':[0.,1.4,16.,17.4,32.,33.4,48.,49.4,64.,65.4],
 'bursts':[0.,1.4,2.8,25.,26.4,27.8,50.,51.4,52.8,54.2]})
results=[]
for gain,b,gap in itertools.product([.3,.6,1.,1.4,1.8,2.4],[.06,.12,.24,.4],[2.,3.,4.]):
 scores={}
 for name,times in schedules.items():
  d=Device(np.broadcast_to(NOMINAL,(3,5)).tolist(),.1,[.025]*3,np.log([.3,gain,.3]).tolist(),b,[0]*3)
  r=simulate([[],times,[]],d,180.)
  d.initial_z=np.log(r['final_gain']).tolist();d.initial_b=r['final_b']
  p=simulate([[],[k*gap for k in range(8)],[]],d,8*gap+20,mode='fixed')
  scores[name]=sum(sum(k*gap<=t<(k+1)*gap for t in p['outputs'])==1 for k in range(8))
 results.append(dict(gain=gain,b=b,target=gap,scores=scores))
Path('audit_runs/pedagogy_development/grid.json').write_text(json.dumps(dict(schedules=schedules,results=results),indent=2))
for r in results:
 s=r['scores']
 if max(s.values())==8 and min(s.values())<8:print(r['gain'],r['b'],r['target'],','.join(k for k,v in s.items() if v==8),flush=True)
